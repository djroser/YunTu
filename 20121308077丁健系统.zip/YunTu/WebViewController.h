//
//  WebViewController.h
//  abiz-best
//
//  Created by zhuangch on 15/7/3.
//  Copyright (c) 2015年 focustech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface WebViewController : BaseViewController

@property(nonatomic, retain) NSURL *linkUrl;

@property(nonatomic, assign) BOOL isAboutYuntu;

@end
