//
//  UIImage+Resize.h
//  YunTu
//
//  Created by 丁健 on 15/11/29.
//  Copyright © 2015年 丁健. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Resize)
- (UIImage *)resizeToSize:(CGSize)newSize;
@end
