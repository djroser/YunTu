//
//  YTGlobalDetailItem.h
//  YunTu
//
//  Created by 丁健 on 16/5/5.
//  Copyright © 2016年 丁健. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YTGlobalDetailItem : NSObject

@property (nonatomic, copy) NSString *sTitle;

@property (nonatomic, copy) NSString *sSubTitle;

@property (nonatomic, copy) NSString *imageTitle;

@end
