//
//  YTExamResultItem.h
//  YunTu
//
//  Created by 丁健 on 16/5/13.
//  Copyright © 2016年 丁健. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YTExamResultItem : NSObject

@property(nonatomic,copy)NSString *stuNum;
@property(nonatomic,copy)NSString *stuName;
@property(nonatomic,copy)NSString *stuMajor;
@property(nonatomic,copy)NSString *examDate;
@property(nonatomic,copy)NSString *examScore;

@end
