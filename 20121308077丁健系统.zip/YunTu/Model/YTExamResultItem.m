//
//  YTExamResultItem.m
//  YunTu
//
//  Created by 丁健 on 16/5/13.
//  Copyright © 2016年 丁健. All rights reserved.
//

#import "YTExamResultItem.h"

@implementation YTExamResultItem

@end
