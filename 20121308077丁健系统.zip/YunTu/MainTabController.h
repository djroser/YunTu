//
//  MainTabController.h
//  YunTu
//
//  Created by 丁健 on 15/12/13.
//  Copyright © 2015年 丁健. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainTabController : UITabBarController

@end
