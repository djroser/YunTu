//
//  QuestionCell.m
//  YunTu
//
//  Created by 丁健 on 15/11/3.
//  Copyright © 2015年 丁健. All rights reserved.
//

#import "QuestionCell.h"

@implementation QuestionCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
