//
//  MyHeadView.h
//  YunTu
//
//  Created by 丁健 on 16/4/9.
//  Copyright © 2016年 丁健. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyHeadView : UIView

@property (weak, nonatomic) IBOutlet UIImageView *imgvUserType;
@property (weak, nonatomic) IBOutlet UILabel *lblUserName;
@property (weak, nonatomic) IBOutlet UIButton *btnLogin;


@end
