//
//  YTButton.h
//  YunTu
//
//  Created by 丁健 on 15/11/3.
//  Copyright © 2015年 丁健. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YTButton : UIButton

@end
