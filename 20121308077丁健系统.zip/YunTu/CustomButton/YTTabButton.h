//
//  YTTabButton.h
//  YunTu
//
//  Created by 丁健 on 16/4/26.
//  Copyright © 2016年 丁健. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YTTabButton : UIButton

@end
